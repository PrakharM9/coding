#include<iostream>
using namespace std;
/*This is used namesapce and it will automaticall*/
int main(){
    int x;
    cin >> x;

}