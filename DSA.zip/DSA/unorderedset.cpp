#include<bits/stdc++.h>
using namespace std;
int main(){
    //in unordered set time complexity is o(1) and its time complexity for worst case whcih happens once in a million is o(n)
    //lower_bound and upper_bound function does not works,rest all functions are same;
    //It does not stores in any particular order
    //it has better complexity than set in most cases except some when collisions happens
    return 0;
}