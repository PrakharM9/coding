#include<bits/stdc++.h>
using namespace std;
int main(){
    //The main difference is that here we can store duplicate keys but everything in a sorted order
    //mpp[key] can not be used here
    
    return 0;
}
