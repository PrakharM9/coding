#include <bits/stdc++.h>
using namespace std;

int main()
{
  int array[4][3];
  for(int i=0;i<4;i++){
    for(int j=0;j<3;j++){
        array[i][j]=1;
    }
  }
  return 0;
}