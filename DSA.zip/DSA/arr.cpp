#include <bits/stdc++.h>
using namespace std;

int main()
{
  int num;
  cin>>num;
  cout<<"my name is prakhar "
  return 0;
}