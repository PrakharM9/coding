#include <bits/stdc++.h>
using namespace std;

int main()
{
  string str="dsas";
  sort(str.begin(),str.end());
  cout<<str;
  return 0;
}