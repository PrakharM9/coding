#include <bits/stdc++.h>
using namespace std;
class Solution {
public:
    int firstUniqChar(string s) {
        for(int i=1;i<s.size();i++){
            cout<<s[i]<<" ";
        }
        cout<<endl;123
    }
};
int main()
{
  Solution sol;
  sol.firstUniqChar("loveleetcode");
  return 0;
}