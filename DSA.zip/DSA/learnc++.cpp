#include<bits/stdc++.h>
using namespace std;
// int main(){
//     cout << "Hey Prakhar!";
//     //to print the remaining code in next line we will write like
//     cout << "Hey Prakhar!" << "\n";
//     //we can also write like
//     cout << "Hey Prakhar!" << endl;
//     return 0;
// }

// int main(){
//     int x, y;
//     cin >> x >> y;
//     cout << "Value of x: " << x << " and y: " << y;
//     return 0;
// }

int main(){
    // //int
    // int x=10;
    // cout>>
    // //long
    // long x=15;
    // cin >> x;
    // //long long
    // long long x = 15000;
    // //float , double
    // float x=5.6;
    // float y=5;
    // cout << "Value of y: " << y;
    //string and getline
    string s1;
    cin >> s1;
    cout << s1;
    //for full line
    string str2;
    getline(cin,str2);
    cout << str2;
    return 0;
}