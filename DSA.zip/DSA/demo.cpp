#include<bits/stdc++.h>
using namespace std;
int main(){
    int x;
    cin >> x;
    cout << "Hey " <<x;
}