#include<bits/stdc++.h>
using namespace std;
int main(){
    //It will have unique keys but it will not be sorted.rest all is same as map
}